package com.t3h.miniproject;

class Const {
    public static final String EXTRA_URL = "url";
}
