package com.t3h.buoi10;

class Const {
    public static final String EXTRA_URL = "url";
}
