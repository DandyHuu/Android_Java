package com.t3h.appdc.model;

public class Account {
    private String username;

    private String pass;

    private int roles;

    private String phone;

    private String email;


}
